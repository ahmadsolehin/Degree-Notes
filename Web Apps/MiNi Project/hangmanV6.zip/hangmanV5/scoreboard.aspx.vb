﻿
Partial Class scoreboard
    Inherits System.Web.UI.Page

End Class
