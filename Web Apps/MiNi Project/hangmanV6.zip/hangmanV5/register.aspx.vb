﻿Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient

Partial Class register
    Inherits System.Web.UI.Page
    Protected Sub RegisterUser(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        Dim userId As Integer = 0
        Dim constr As String = ConfigurationManager.ConnectionStrings("ConnectionString2").ConnectionString
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("Insert_User")
                Using sda As New SqlDataAdapter()
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@Username", txtUsername.Text.Trim())
                    cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim())
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim())
                    cmd.Connection = con
                    con.Open()
                    userId = Convert.ToInt32(cmd.ExecuteScalar())
                    con.Close()
                End Using
            End Using
            Dim message As String = String.Empty
            Select Case userId
                Case -1
                    message = "Username already exists.\nPlease choose a different username."
                    Exit Select
                Case -2
                    message = "Supplied email address has already been used."
                    Exit Select
                Case Else
                    message = "Registration successful.\nUser Id: " + userId.ToString() + ".\nPlease login at main page."
                        Exit Select
            End Select
            ClientScript.RegisterStartupScript([GetType](), "alert", (Convert.ToString("alert('") & message) + "');", True)
        End Using
    End Sub

    Protected Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        txtUsername.Text = Nothing
        txtPassword.Text = Nothing
        txtConfirmPassword.Text = Nothing
        txtEmail.Text = Nothing
    End Sub

End Class
