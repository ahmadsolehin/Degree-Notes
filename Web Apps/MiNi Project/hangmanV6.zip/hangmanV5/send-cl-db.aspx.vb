﻿
Partial Class send_cl_db
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("name") Is Nothing Then
            Response.Redirect("login-failed.aspx")
        End If
        lblName.Text = Session("name")
        Label2.Text = "Hi, " & Session("name") & " ! Please select word / phrase to be guessed by the player :"
    End Sub

    Protected Sub ImageButton2_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton2.Click
        Session.Add("player", DropDownList1.SelectedValue)
        Session.Add("word", DropDownList2.SelectedValue)
        Response.Redirect("enter-cl-db.aspx")
    End Sub
End Class
