﻿Imports Microsoft.VisualBasic

Namespace System
    Public Class Windows

    End Class
End Namespace
