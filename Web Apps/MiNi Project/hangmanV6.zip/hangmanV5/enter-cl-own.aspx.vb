﻿
Partial Class enter_cl_own
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("name") Is Nothing Then
            Response.Redirect("login-failed.aspx")
        End If
        Label2.Text = "Hi, " & Session("name") & " ! You've sent a challenge to  " & Session("player") & "."
        lblDateTime.Text = DateTime.Now.ToString("dd-MM-yyyy h:mmtt")
        SqlDataSource1.InsertCommand = "insert into tblChallenge (player_username, challengeby, word_phrase, date_time) values('" & Session("player") & "', '" & Session("name") & "', '" & Session("word") & "', '" & lblDateTime.Text & "')"
        SqlDataSource1.Insert()
    End Sub
End Class
