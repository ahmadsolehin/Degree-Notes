﻿
Partial Class login_failed
    Inherits System.Web.UI.Page

End Class
