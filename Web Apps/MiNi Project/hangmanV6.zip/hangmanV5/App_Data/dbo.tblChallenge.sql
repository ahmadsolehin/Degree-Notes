﻿CREATE TABLE [dbo].[tblChallenge]
(
	[ChallengeId] INT NOT NULL PRIMARY KEY, 
    [player_username] NVARCHAR(50) NULL, 
    [challengeby] NVARCHAR(50) NULL, 
    [word_phrase] TEXT NULL, 
    [date_time] DATETIME NULL
)
