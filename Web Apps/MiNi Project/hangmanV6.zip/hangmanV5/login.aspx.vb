﻿Imports System.Data.OleDb
Imports System.Data

Partial Class _Default
    Inherits System.Web.UI.Page
    Dim cn As New OleDbConnection
    Dim cmd As New OleDbCommand
    Dim dr As OleDbDataReader

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label7.Text = DateTime.Now.ToString("dd-MM-yyyy h:mmtt")

    End Sub

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "" Or txtPassword.Text = "" Then Exit Sub

        Dim dv As DataView
        dv = CType(SqlDataSource2.Select(DataSourceSelectArguments.Empty), DataView)
        If dv.Count = 1 Then
            Session.Add("name", txtUsername.Text)
            SqlDataSource1.UpdateCommand = "update tblUser set LastLoginDate ='" & Label7.Text & "'where Username = '" & txtUsername.Text & "'"
            SqlDataSource1.Update()
            Response.Redirect("login-success.aspx")
        Else
            Response.Redirect("login-failed.aspx")
        End If
    End Sub

    Protected Sub btnReset_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnReset.Click
        txtUsername.Text = Nothing
        txtPassword.Text = Nothing
    End Sub

End Class
