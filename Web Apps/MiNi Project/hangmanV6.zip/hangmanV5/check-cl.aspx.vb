﻿Imports System.Data
Partial Class check_cl
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("name") Is Nothing Then
            Response.Redirect("login-failed.aspx")
        Else
            'check if user got any challenges to play
            lblName.Text = Session("name")
            Dim sqlstr As String = "select * from tblChallenge where player_username ='" & lblName.Text & "'"
            SqlDataSource1.SelectCommand = sqlstr
            SqlDataSource1.Select(DataSourceSelectArguments.Empty)

            Dim dv As DataView
            dv = CType(SqlDataSource1.Select(DataSourceSelectArguments.Empty), DataView)
            If (dv.Count < 1) Then
                lblMsg.Visible = True
            Else
                lblMsg.Visible = False
                GridView1.Visible = True
            End If
        End If
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView1.SelectedIndexChanged
        Label.Text = GridView1.SelectedDataKey.Value.ToString()
        Session.Add("play-id", Label.Text)
        Response.Redirect("play-cl.aspx")
    End Sub
End Class
