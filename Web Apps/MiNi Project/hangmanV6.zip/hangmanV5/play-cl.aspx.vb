﻿
Partial Class play_cl
    Inherits System.Web.UI.Page

    
End Class
