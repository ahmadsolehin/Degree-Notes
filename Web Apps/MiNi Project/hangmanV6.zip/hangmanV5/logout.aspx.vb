﻿
Partial Class logout
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Session("name") Is Nothing Then
            Response.Redirect("login-failed.aspx")
        Else
            Session.Abandon()
        End If
    End Sub
End Class
