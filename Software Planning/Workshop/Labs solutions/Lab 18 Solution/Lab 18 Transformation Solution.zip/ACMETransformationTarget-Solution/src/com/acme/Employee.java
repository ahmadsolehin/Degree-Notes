/**
 * 
 */
package com.acme;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author JLMARECH
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class Employee {
	
	// New attribute added
	private String name;

	// New getter and setter methods automatically added
	// added by Right-click > Source > Generate Getters and Setters...
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}