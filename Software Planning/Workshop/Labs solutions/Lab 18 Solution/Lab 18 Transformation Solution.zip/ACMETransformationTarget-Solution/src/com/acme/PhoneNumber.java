/**
 * 
 */
package com.acme;

/** 
 * <!-- begin-UML-doc -->
 * <!-- end-UML-doc -->
 * @author JLMARECH
 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
 */
public class PhoneNumber {
	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private String theNumber;

	/** 
	 * <!-- begin-UML-doc -->
	 * <!-- end-UML-doc -->
	 * @param aPhoneNumber
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean isPhoneNumber(String aPhoneNumber) {
		// begin-user-code
		// TODO Auto-generated method stub
		return null;
		// end-user-code
	}
}