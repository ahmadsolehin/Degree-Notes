package com.ibm.rlss.ersa.basic;

public interface Echo {
	public String echo(String message);
}
