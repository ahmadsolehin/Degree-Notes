package com.ibm.rlss.ersa.basic;

public interface Dummy {

}
